@echo off
setlocal
chcp 65001 >nul
set "REG_PYTHON=%~dp0Programa\python.exe"
if not exist "%REG_PYTHON%" (
 echo Falta la carpeta Programa. Extrae toda la carpeta antes de continuar.
 pause
 exit /b 1
)
"%REG_PYTHON%" -I "%~dp0aplicacion_registro.py"
if errorlevel 1 (
 echo La aplicacion no se pudo abrir. Revisa el mensaje anterior.
 pause
 exit /b 1
)
