"""Punto de entrada de la aplicación de registro de atestados.

Doble clic en «Abrir aplicación.cmd» para usarla. No necesita instalación
ni conexión: usa el Python de la carpeta Programa.
"""
from pathlib import Path
import sys

FOLDER = Path(__file__).resolve().parent
sys.path.insert(0, str(FOLDER))

from aplicacion.interfaz_app import main

if __name__ == '__main__':
    main(FOLDER)
